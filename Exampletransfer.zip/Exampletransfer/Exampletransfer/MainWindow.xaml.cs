﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Exampletransfer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<City> CityList;
        public MainWindow()
        {
            InitializeComponent();
            BindLeftList();
        }
        private void BindLeftList()
        {
            CityList = new List<City> {
            new City{CityName="Noida"},
            new City{CityName="Delhi"},
            new City{CityName="Saharanpur"},
            new City{CityName="Jaspur"},
            new City{CityName="Moradabad"},
            new City{CityName="Agra"},
            new City{CityName="Bariely"},
            new City{CityName="Kanpur"},
            new City{CityName="Greater Noida"}
            };

            LeftListBox.ItemsSource = CityList.Select(x => x.CityName);
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            if (LeftListBox.SelectedIndex > -1)
            {
                string currentItemText = LeftListBox.SelectedValue.ToString();
               int currentItemIndex = LeftListBox.SelectedIndex;

                RightListBox.Items.Add(currentItemText);
                if (CityList != null)
                {
                    CityList.RemoveAt(currentItemIndex);
                    LeftListBox.ItemsSource = null;
                    LeftListBox.ItemsSource = CityList.Select(x => x.CityName);
                }
            }
            else
            {
                System.Windows.MessageBox.Show("Please Select An Item To add");
            }
        }

        private void RemoveButton_Click(object sender, RoutedEventArgs e)
        {
            if (RightListBox.SelectedIndex > -1)
            {
                 string currentItemText = RightListBox.SelectedValue.ToString();
               int currentItemIndex = RightListBox.SelectedIndex;

                City city = new City();
                city.CityName = currentItemText;
                CityList.Add(city);
                RightListBox.Items.RemoveAt(RightListBox.Items.IndexOf(RightListBox.SelectedItem));

                LeftListBox.ItemsSource = null;
                LeftListBox.ItemsSource = CityList.Select(x => x.CityName);

            }
            else
            {
                System.Windows.MessageBox.Show("Please Select An Item To Remove");
            }
        
    }
    }
}

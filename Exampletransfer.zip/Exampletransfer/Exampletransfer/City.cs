﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exampletransfer
{
    class City
    {
        public string CityName
        {
            get;
            set;
        }
    }
}
